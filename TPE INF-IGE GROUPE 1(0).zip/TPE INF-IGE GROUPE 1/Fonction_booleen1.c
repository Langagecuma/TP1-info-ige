#include<stdio.h>
#include<stdlib.h>
struct date{
	int jour, mois, annee;
};
int booleen(struct date date1,struct date date2)
{
	char c;
	 if(date1.annee==date2.annee)
 {
 	if(date1.mois==date2.mois)
	 {
 		if(date1.jour==date2.jour)
			 {
	 			printf("Les deux date son identique");
			 }
		 else if(date1.jour<date2.jour)
			 {
			 	c='v';
			 	printf("%c\n",c);
			 	printf("la date1 vient avant date2");
			 }
			  else{
			  	c='F';
			  	printf("%c\n",c);
			  	printf("la date1 vient apres date2");
			  }
	 }
	else if(date1.mois<date2.mois)
	{
			c='V';
			printf("%c\n",c);
			printf("la date1 vient avant date2");
	}
	 else{
	 			c='F';
	 			printf("%c\n",c);
			  	printf("la date1 vient apres date2");
			  }
 }
 else if (date1.annee>date2.annee)
 {
	c='F';
	printf("%c\n",c);
    printf("la date1 vient apres date2");
 }
 else{
 	c='V';
 	printf("%c\n",c);
 	printf("la date1 vient avant date2");
 }
 return c;
}
int main()
{
	struct date date1;
	struct date date2;
	char date;
		printf("Entrez  la premiere date\n");
	scanf("%ddate1.jour",&date1.jour);
 	scanf("%ddate1.mois",&date1.mois);
 	scanf("%ddate1.annee",&date1.annee);
 	
 	printf("Entrez la deuxieme dates\n");
 	scanf("%ddate2.jour",&date2.jour);
	scanf("%ddate2.mois",&date2.mois);
 	scanf("%ddate2.annee",&date2.annee);
 	date=booleen(date1,date2);
 	return 0;	
}
