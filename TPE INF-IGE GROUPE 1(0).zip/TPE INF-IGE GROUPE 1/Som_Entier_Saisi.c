#include <stdio.h>
#include <stdlib.h>
int main()
{	
int val=0,som=0;
	printf("Enterz une valeur:\n");
	scanf("%d",&val);
	som=val;
		while(val!=0)
	{
		printf("entrer une autre valeur\n");
		scanf("%d",&val);
		som=som+val;
	}
	printf("La somme de ces entiers saisie est %d \n",som);
	return 0;
}
