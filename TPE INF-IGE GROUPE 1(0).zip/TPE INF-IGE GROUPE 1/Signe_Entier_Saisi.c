#include <stdio.h>
#include <stdlib.h>

int main() {
	 int A=0;
	 printf("entrez la valeur de A:\n");
	 scanf("%d",&A);
	 if(A==0){
	 	printf("La valeur de A est nul\n");
	 }
	 else if(A>0){
	 	printf("La valeur de A est positive\n");
	 }
	 else {
	 	printf("La valeur de A est negative");
	 }
	return 0;
}
