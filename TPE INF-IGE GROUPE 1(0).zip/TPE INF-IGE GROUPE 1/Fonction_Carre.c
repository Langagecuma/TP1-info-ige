#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int carre_reel(float n)
{
	float c=0.0;
	c=pow(n,2);
	return c;
}
int main()
{
	float c=0.0,n=0.0;
	printf("Entrez une valeur :");
	scanf("%f",&n);
	c=carre_reel(n);
	printf("Le carre de la valeur est %f",c);
	return c;
}
