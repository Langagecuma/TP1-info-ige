#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main()
{
	int A=0,B=0,C=0;
	printf("Enterz la valeur de A : \n");
	scanf("%d",&A);
	printf("Enterz la valeur de B: \n");
	scanf("%d",&B);
	C=A;
	A=B;
	B=C;
	printf("la nouvelle valeur de A est %d et la nouvelle valeur de B est %d",A,B);
	return 0;
}
