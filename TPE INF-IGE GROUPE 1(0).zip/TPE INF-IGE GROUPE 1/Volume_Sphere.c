#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main()
{
	float V=0.0,r=0.0;
	printf("Enterz le rayon:\n");
	scanf("%f",&r);
	V=(4*3.14*r*r*r)/3;
	printf("le volume est %f",V);
	return 0;
}
